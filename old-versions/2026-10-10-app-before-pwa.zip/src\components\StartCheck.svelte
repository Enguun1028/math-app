<script>
  // "Хаанаас эхлэх вэ?": short sections, simplest first. Stop any time, partial results are kept.
  // The goal shapes the check: "Шалгалтаа давах" first asks what the test is about and checks only what leads there.
  import { fly } from 'svelte/transition';
  import { spheres, sphereById } from '../lib/content.js';
  import { sphereQuestions, applySphereTest, PASS } from '../lib/logic.js';
  import { progress, save } from '../lib/progress.svelte.js';
  import { go } from '../lib/router.svelte.js';
  import { ms, ease } from '../lib/motion.js';
  import Quiz from './Quiz.svelte';

  // A sphere and every sphere it needs, in journey order.
  function leadsTo(id) {
    const need = new Set();
    const add = (s) => { if (need.has(s)) return; need.add(s); sphereById[s].needs.forEach(add); };
    add(id);
    return spheres.filter((s) => need.has(s.id));
  }

  let target = $state(progress.goal === 'test' ? progress.testSphere ?? null : null);
  let asking = $derived(progress.goal === 'test' && !target);
  let sections = $derived((target ? leadsTo(target) : spheres).filter((s) => s.entries.length));
  let at = $state(0);
  let score = $state(null);
  let s = $derived(sections[at]);
  let questions = $derived(s ? sphereQuestions(s, 1) : []);

  function pick(id) {
    target = id;
    progress.testSphere = id;
    save();
  }
  function done(_, results) {
    score = applySphereTest(s, questions, results);
  }
  function cont() {
    at += 1;
    score = null;
  }
</script>

{#if asking}
  <header class="head">
    <p class="small muted">Хаанаас эхлэх вэ?</p>
    <h1>Шалгалт чинь юуны тухай вэ?</h1>
    <p class="muted">Сэдвээ сонго. Түүнд хүрэх замыг л шалгана.</p>
  </header>
  <div class="pick">
    {#each spheres as sp, i}
      <button class="opt" onclick={() => pick(sp.id)} in:fly={{ y: 12, duration: ms(260), delay: ms(i * 30), easing: ease }}>
        <span class="f">{sp.formula}</span>{sp.title}
      </button>
    {/each}
  </div>
{:else if !s}
  <section class="card stack">
    <h2>Энэ сэдвийн асуултууд удахгүй нэмэгдэнэ.</h2>
    <button class="btn primary" onclick={() => go('/')}>Газрын зургаа харах</button>
  </section>
{:else}
  <header class="head">
    <p class="small muted">Хаанаас эхлэх вэ? · {at + 1}-р хэсэг / {sections.length}</p>
    <h1>{s.title}</h1>
    <p class="muted">Мэдэхгүй бол таамаглах хэрэггүй. Энэ бол дүн биш, зөвхөн эхлэх газраа олох арга.</p>
  </header>

  <section class="card">
    {#if score === null}
      {#key at}<div in:fly={{ x: 24, duration: ms(280), easing: ease }}><Quiz {questions} ondone={done} /></div>{/key}
    {:else}
      <div class="stack" in:fly={{ y: 12, duration: ms(280), easing: ease }}>
        <h2>{Math.round(score * questions.length)} / {questions.length} зөв</h2>
        <p>
          {#if score >= PASS}Энэ хэсгийг мэддэг байна. Газрын зурагт тэмдэглэлээ.{:else}Энэ хэсгээс эхэлбэл хамгийн тохиромжтой.{/if}
        </p>
        <div class="row">
          {#if at < sections.length - 1 && score >= PASS}
            <button class="btn sun" onclick={cont}>Үргэлжлүүлэх →</button>
          {/if}
          <button class="btn" class:primary={score < PASS || at === sections.length - 1} onclick={() => go('/')}>Газрын зургаа харах</button>
        </div>
      </div>
    {/if}
  </section>
{/if}

<style>
  .head { padding: 16px 0; display: grid; gap: 6px; }
  h1 { font-size: 1.6rem; font-weight: 800; }
  .row { display: flex; gap: 8px; flex-wrap: wrap; }
  .pick { display: grid; gap: 8px; }
  .opt { display: flex; align-items: center; gap: 12px; padding: 10px 12px; border-radius: 14px; border: 1px solid var(--line); background: var(--surface); text-align: left; font-weight: 700; }
  .opt:hover { border-color: var(--sky); }
  .f { min-width: 56px; height: 40px; padding: 0 8px; display: grid; place-items: center; border-radius: 10px; background: var(--sky-soft); color: var(--sky); font-family: var(--math); white-space: nowrap; }
</style>
