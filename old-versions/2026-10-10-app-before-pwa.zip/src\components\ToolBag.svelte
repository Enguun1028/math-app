<script>
  // Tool bag: tools always one tap away.
  import { ui } from '../lib/ui.svelte.js';
  import Visual from './Visual.svelte';
  import { fly, fade } from 'svelte/transition';
  import { sheetIn, sheetOut, scrimFade, ms, ease } from '../lib/motion.js';

  const tools = [
    { id: 'numberline', name: 'Тооны шулуун' },
    { id: 'scale', name: 'Жин' },
    { id: 'fraction', name: 'Бутархайн зурвас' },
    { id: 'grid', name: 'Талбайн тор' },
    { id: 'coord', name: 'Координатын хавтгай' },
  ];

  let a = $state(2);
  let b = $state(3);
  let l1 = $state(3), l2 = $state(4), r1 = $state(2), r2 = $state(5);
  let num = $state(3), den = $state(4);
  let rows = $state(3), cols = $state(4);

  // Switching tools: the new one glides in from the side of the tab you tapped; the highlight slides along.
  let dir = $state(1);
  const pickTool = (id) => {
    dir = tools.findIndex((t) => t.id === id) >= tools.findIndex((t) => t.id === ui.tool) ? 1 : -1;
    ui.tool = id;
  };
  let tabEls = $state({});
  let pill = $derived.by(() => {
    const el = tabEls[ui.tool];
    return el ? { x: el.offsetLeft, w: el.offsetWidth } : null;
  });

  let v = $derived.by(() => {
    switch (ui.tool) {
      case 'numberline': return { kind: 'numberline', from: -10, to: 10, marks: [a, a + b], jump: [a, a + b] };
      case 'scale': return { kind: 'scale', left: `${l1} + ${l2}`, right: `${r1} + ${r2}` };
      case 'fraction': return { kind: 'fraction', num: Math.min(num, den), den };
      case 'grid': return { kind: 'grid', rows, cols };
      default: return null;
    }
  });
</script>

<button class="fab" onclick={() => (ui.tools = !ui.tools)} aria-expanded={ui.tools} aria-label="Хэрэгслийн цүнх">
  <svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="7" width="18" height="13" rx="3" /><path d="M9 7V5a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2M3 12h18" /></svg>
</button>

{#if ui.tools}
  <div class="scrim" onclick={() => (ui.tools = false)} role="presentation" transition:fade={scrimFade}></div>
  <div class="sheet" role="dialog" aria-label="Хэрэгслийн цүнх" in:fly={sheetIn} out:fly={sheetOut}>
    <div class="top">
      <h2>Хэрэгслийн цүнх</h2>
      <button class="btn ghost" onclick={() => (ui.tools = false)}>Хаах</button>
    </div>
    <div class="tabs">
      {#if pill}<span class="pill" style:transform="translateX({pill.x}px)" style:width="{pill.w}px"></span>{/if}
      {#each tools as t}
        <button class="chip" class:on={ui.tool === t.id} bind:this={tabEls[t.id]} onclick={() => pickTool(t.id)}>{t.name}</button>
      {/each}
    </div>

    {#key ui.tool}
    <div class="tool" in:fly={{ x: 28 * dir, duration: ms(280), easing: ease }}>
    {#if v}
      <Visual {v} />
      <div class="ctl">
        {#if ui.tool === 'numberline'}
          <label>Эхлэх: <b>{a}</b><input type="range" min="-10" max="10" bind:value={a} /></label>
          <label>Алхам: <b>{b > 0 ? '+' : ''}{b}</b><input type="range" min={-10 - a} max={10 - a} bind:value={b} /></label>
          <p class="res">{a} {b < 0 ? '−' : '+'} {Math.abs(b)} = <b>{a + b}</b></p>
        {:else if ui.tool === 'scale'}
          <div class="pair"><span>Зүүн:</span><input type="number" bind:value={l1} /> + <input type="number" bind:value={l2} /></div>
          <div class="pair"><span>Баруун:</span><input type="number" bind:value={r1} /> + <input type="number" bind:value={r2} /></div>
          <p class="res">{l1 + l2 === r1 + r2 ? 'Тэнцвэртэй: = үнэн' : 'Тэнцвэргүй: = худал'}</p>
        {:else if ui.tool === 'fraction'}
          <label>Хүртвэр: <b>{Math.min(num, den)}</b><input type="range" min="0" max={den} bind:value={num} /></label>
          <label>Хуваарь: <b>{den}</b><input type="range" min="1" max="12" bind:value={den} /></label>
        {:else if ui.tool === 'grid'}
          <label>Мөр: <b>{rows}</b><input type="range" min="1" max="10" bind:value={rows} /></label>
          <label>Багана: <b>{cols}</b><input type="range" min="1" max="10" bind:value={cols} /></label>
        {/if}
      </div>
    {:else}
      <p class="card muted">Удахгүй нэмэгдэнэ.</p>
    {/if}
    </div>
    {/key}
  </div>
{/if}

<style>
  .fab {
    position: fixed; right: max(16px, calc(50vw - 264px)); bottom: calc(20px + env(safe-area-inset-bottom)); z-index: 30;
    width: 56px; height: 56px; border-radius: 18px; border: 0; background: var(--surface-solid); color: var(--sky); border: 1px solid rgba(34, 211, 238, 0.5);
    display: grid; place-items: center; box-shadow: 0 8px 24px rgba(21, 32, 51, 0.3);
  }
  .fab svg { width: 26px; height: 26px; fill: none; stroke: currentColor; stroke-width: 2; stroke-linejoin: round; }
  .fab:focus-visible { outline: 3px solid var(--sky); outline-offset: 3px; }
  .scrim { position: fixed; inset: 0; background: rgba(21, 32, 51, 0.3); z-index: 40; }
  .sheet {
    position: fixed; left: 0; right: 0; bottom: 0; z-index: 41; max-height: 85vh; overflow-y: auto;
    max-width: 560px; margin: 0 auto; padding: 16px 16px calc(20px + env(safe-area-inset-bottom));
    background: var(--surface); border-radius: 22px 22px 0 0; box-shadow: 0 -8px 32px rgba(21, 32, 51, 0.18);
    display: grid; gap: 12px;
  }
  .top { display: flex; justify-content: space-between; align-items: center; }
  .tabs { position: relative; display: flex; gap: 8px; overflow-x: auto; scrollbar-width: none; }
  .tabs .chip { flex: none; position: relative; z-index: 1; transition: color 0.25s, border-color 0.25s; }
  .tabs .chip.on { background: transparent; border-color: transparent; }
  .pill {
    position: absolute; left: 0; top: 0; height: 36px; border-radius: 999px; background: var(--sky);
    box-shadow: var(--glow); transition: transform 0.32s cubic-bezier(0.22, 0.8, 0.24, 1), width 0.32s cubic-bezier(0.22, 0.8, 0.24, 1);
  }
  .tool { display: grid; gap: 12px; }
  .ctl { display: grid; gap: 10px; }
  label { display: grid; gap: 2px; font-weight: 600; font-size: 0.9rem; }
  input[type='range'] { width: 100%; accent-color: var(--sky); }
  .pair { display: flex; align-items: center; gap: 6px; font-weight: 600; }
  .pair span { width: 64px; }
  .pair input { width: 64px; min-height: 40px; font: inherit; text-align: center; border: 1.5px solid var(--line); border-radius: 10px; }
  .res { font-size: 1.2rem; text-align: center; }
</style>
