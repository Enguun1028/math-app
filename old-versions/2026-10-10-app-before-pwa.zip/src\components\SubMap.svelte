<script>
  // A sphere opened up: a small map of its topics, laid out by what depends on what.
  import { sphereById, topics, topicUnlocks, strands } from '../lib/content.js';
  import { sphereLayout } from '../lib/layout.js';
  import { topicState, sphereState, readiness, sphereKnown } from '../lib/logic.js';
  import { ui } from '../lib/ui.svelte.js';
  import { twoLines } from '../lib/layout.js';
  import { onMount } from 'svelte';
  import { reduced } from '../lib/motion.js';

  let { id } = $props();
  let s = $derived(sphereById[id]);
  let st = $derived(s && sphereState(s));

  const W = 360, ROW = 160, R = 44;
  // Depth inside this sphere: how many in-sphere prerequisites come before a topic.
  let layout = $derived.by(() => {
    if (!s) return { nodes: {}, rows: 0 };
    const inS = new Set(s.topics);
    const depth = {};
    const d = (t) => depth[t] ??= Math.max(0, ...topics[t].req.filter((r) => inS.has(r)).map((r) => d(r) + 1));
    s.topics.forEach(d);
    const rows = [];
    for (const t of s.topics) (rows[depth[t]] ??= []).push(t);
    const nodes = {};
    rows.forEach((row, ri) => row.forEach((t, i) => {
      const x = row.length === 1 ? W / 2 + (ri % 2 ? 40 : -40) : 56 + (i * (W - 112)) / (row.length - 1);
      nodes[t] = { x, y: 70 + ri * ROW };
    }));
    return { nodes, rows: rows.length };
  });
  let edges = $derived(
    s ? s.topics.flatMap((t) => topics[t].req.filter((r) => layout.nodes[r]).map((r) => ({ a: layout.nodes[r], b: layout.nodes[t], on: topicState(r) === 'known' }))) : [],
  );
  let from = $derived(s ? [...new Set(s.topics.flatMap((t) => topics[t].req.filter((r) => !s.topics.includes(r))))] : []);
  let onward = $derived(s ? [...new Set(s.topics.flatMap((t) => topicUnlocks[t].filter((u) => !s.topics.includes(u))))] : []);
  const edge = (a, b) => `M ${a.x} ${a.y + R} C ${a.x} ${(a.y + b.y) / 2}, ${b.x} ${(a.y + b.y) / 2}, ${b.x} ${b.y - R}`;
  const fs = (f) => Math.min(24, 88 / Math.max(3, [...f].length));

  // Opening animation: each topic circle starts exactly where it was inside the sphere on the map
  // and glides to its place here. Lines and text fade in once the circles have landed.
  let mini = $state();
  let morphing = $state(false);
  onMount(() => {
    const m = ui.morph;
    // Cleared after the page's own entrance has started, so that entrance knows to stay still.
    setTimeout(() => (ui.morph = null), 700);
    if (!m || m.sphere !== id || reduced || !mini) return;
    const ctm = mini.getScreenCTM();
    if (!ctm) return;
    morphing = true;
    const els = [...mini.querySelectorAll('[data-t]')];
    for (const el of els) {
      const r0 = m.rects[el.dataset.t], n = layout.nodes[el.dataset.t];
      if (!r0 || !n) continue;
      const sx = ctm.a * n.x + ctm.e, sy = ctm.d * n.y + ctm.f;
      el.style.transformOrigin = `${n.x}px ${n.y}px`;
      el.style.transform = `translate(${(r0.x - sx) / ctm.a}px, ${(r0.y - sy) / ctm.d}px) scale(${r0.r / (R * ctm.a)})`;
    }
    mini.getBoundingClientRect(); // apply the start positions before the glide begins
    requestAnimationFrame(() => {
      for (const el of els) {
        el.style.transition = 'transform 600ms cubic-bezier(0.22, 0.8, 0.24, 1)';
        el.style.transform = '';
      }
      setTimeout(() => (morphing = false), 380);
    });
  });
</script>

{#if !s}
  <p class="card">Ийм бөмбөлөг олдсонгүй.</p>
{:else}
  <div class="page" class:morphing style:--c={sphereLayout[s.id].color}>
    <header class="head">
      <p class="small muted">{s.index + 1}-р бөмбөлөг</p>
      <h1>{s.title}</h1>
      <p class="muted">{s.why}</p>
      {#if st === 'known' || st === 'faded'}<span class="badge known">Мэднэ</span>{:else if st === 'next'}<span class="badge next">Дараагийн алхам энд байна</span>{/if}
    </header>

    {#if from.length}
      <div class="edge-row">
        <span class="small muted">Эндээс ирнэ:</span>
        {#each from as f}<button class="chip {topicState(f)}" onclick={() => (ui.topic = f)}><span class="dot"></span>{topics[f].name}</button>{/each}
      </div>
      {#if readiness(s) < 1 && !sphereKnown(s)}
        <p class="note small">
          {#if readiness(s) > 0}Суурь сэдвүүдийн {Math.round(readiness(s) * 100)}% нь танд бий.{/if}
          Эхлээд эдгээр суурийг үзвэл илүү амархан. Гэхдээ хүссэнээ үзэж болно.
        </p>
      {/if}
    {/if}

     <svg bind:this={mini} viewBox="0 0 {W} {layout.rows * ROW}" class="mini" role="group" aria-label="{s.title}: сэдвүүд">
      {#each edges as e}<path d={edge(e.a, e.b)} class="e" class:on={e.on} />{/each}
      {#each s.topics as t (t)}
        {@const n = layout.nodes[t]}
        {@const ts = topicState(t)}
        <g
          data-t={t}
          class="node {ts}"
          style:--tc={strands[topics[t].strand].color}
          role="button"
          tabindex="0"
          aria-label={topics[t].name}
          onclick={() => (ui.topic = t)}
          onkeydown={(ev) => (ev.key === 'Enter' || ev.key === ' ') && (ui.topic = t)}
        >
          {#if ts === 'next'}<circle cx={n.x} cy={n.y} r={R + 8} class="halo" />{/if}
          <circle cx={n.x} cy={n.y} r={R} class="c" />
          <text x={n.x} y={n.y + 1} class="f" font-size={fs(topics[t].formula)}>{topics[t].formula}</text>
          {#each twoLines(topics[t].name, 16) as line, j}
            <text x={n.x} y={n.y + R + 20 + j * 16} class="n">{line}</text>
          {/each}
          {#if ts === 'known' || ts === 'faded'}<text x={n.x + R * 0.75} y={n.y - R * 0.7} class="ok">✓</text>{/if}
        </g>
      {/each}
    </svg>

    {#if onward.length}
      <div class="edge-row">
        <span class="small muted">Цааш нээгдэх:</span>
        {#each onward as o}<button class="chip {topicState(o)}" onclick={() => (ui.topic = o)}><span class="dot"></span>{topics[o].name}</button>{/each}
      </div>
    {/if}

    <div class="actions">
      {#if s.entries.length}
        <a class="btn primary" href="#/test/{s.id}">Бүх бөмбөлгийн шалгалт</a>
      {/if}
      <button class="btn" onclick={() => { ui.fly = { sphere: s.id }; location.hash = '/'; }}>Газрын зураг дээр харах</button>
    </div>
  </div>
{/if}

<style>
  /* While circles glide in, everything else waits, then fades in. */
  .page > :not(.mini), .e, .n, .ok, .halo { transition: opacity 0.35s ease-out, transform 0.35s ease-out; }
  .page.morphing > :not(.mini) { opacity: 0; transform: translateY(8px); }
  .page.morphing .e, .page.morphing .n, .page.morphing .ok, .page.morphing .halo { opacity: 0; }
  .head { padding: 12px 0 16px; display: grid; gap: 6px; justify-items: start; }
  h1 { font-size: 1.8rem; font-weight: 800; letter-spacing: -0.01em; color: var(--c); text-shadow: 0 0 18px color-mix(in srgb, var(--c) 50%, transparent); }
  .edge-row { display: flex; flex-wrap: wrap; gap: 8px; align-items: center; margin: 6px 0; }
  .edge-row .chip { background: transparent; color: var(--ink); }
  .note { padding: 10px 12px; border-radius: 12px; background: var(--sun-soft); margin: 6px 0; }
  .mini { width: 100%; height: auto; margin: 8px 0; overflow: visible; }
  .e { fill: none; stroke: var(--line); stroke-width: 2; }
  .e.on { stroke: var(--sky); stroke-opacity: 0.8; filter: drop-shadow(0 0 4px var(--sky)); }
  .node { cursor: pointer; outline: none; }
  .c { fill: color-mix(in srgb, var(--tc) 22%, var(--bg)); stroke: var(--tc); stroke-width: 1.5; stroke-opacity: 0.75; filter: drop-shadow(0 0 6px color-mix(in srgb, var(--tc) 40%, transparent)); }
  .node:hover .c, .node:focus-visible .c { stroke-width: 3; stroke-opacity: 1; }
  .node.known .c { fill: color-mix(in srgb, var(--tc) 35%, var(--bg)); stroke-opacity: 1; stroke-width: 3; filter: drop-shadow(0 0 8px var(--tc)); }
  .node.faded .c { stroke: var(--dusk); }
  .node.later { opacity: 0.55; }
  .halo { fill: none; stroke: var(--sun); stroke-width: 3; animation: pulse 2.2s ease-in-out infinite; }
  @keyframes pulse { 50% { stroke-opacity: 0.25; } }
  .f { fill: #fff; text-anchor: middle; dominant-baseline: middle; font-family: var(--math); filter: drop-shadow(0 0 5px var(--tc)); pointer-events: none; }
  .n { fill: var(--ink); font-size: 13px; font-weight: 600; text-anchor: middle; pointer-events: none; }
  .ok { fill: var(--grass); font-size: 16px; font-weight: 800; pointer-events: none; }
  .actions { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 16px; }
  .actions a { text-decoration: none; }
  @media (prefers-reduced-motion: reduce) { .halo { animation: none; } }
</style>
