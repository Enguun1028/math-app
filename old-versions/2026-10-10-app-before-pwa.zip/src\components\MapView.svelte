<script>
  // The explorable neon map. It scrolls like a feed and zooms in (never farther out than the start view).
  // Topics appear inside spheres as you zoom in. Spheres drift very slightly, like a slow DVD-logo bounce.
  import { onMount } from 'svelte';
  import { fly } from 'svelte/transition';
  import { spheres, topics, topicUnlocks, sphereById } from '../lib/content.js';
  import { sphereLayout, topicLayout, world, twoLines } from '../lib/layout.js';
  import { topicState, sphereState, nextTopic, GOALS, levelChecked } from '../lib/logic.js';
  import { progress, save } from '../lib/progress.svelte.js';
  import { ui } from '../lib/ui.svelte.js';
  import { go } from '../lib/router.svelte.js';
  import { search } from '../lib/search.js';
  import { looksLikeMath, formatMath } from '../lib/mathfmt.js';
  import { ms, ease, reduced } from '../lib/motion.js';

  let W = $state(400);
  let H = $state(800);
  let cam = $state(ui.cam ?? { x: 0, y: 0, k: 0.3 });
  let svg;

  // Level of detail: topics fade in as you zoom.
  let detail = $derived(Math.min(1, Math.max(0, (cam.k - 0.42) / 0.28)));
  let next = $derived(nextTopic());
  let selected = $derived(ui.topic);

  let q = $state('');
  let results = $derived(search(q));

  // Faint stars scattered through the world.
  const stars = Array.from({ length: 220 }, (_, i) => {
    const r = (n) => ((Math.sin(i * 127.1 + n * 311.7) * 43758.5453) % 1 + 1) % 1;
    return { x: world.minX - 600 + r(1) * (world.maxX - world.minX + 1200), y: world.minY - 600 + r(2) * (world.maxY - world.minY + 1200), s: 0.6 + r(3) * 2.2, o: 0.15 + r(4) * 0.5 };
  });

  // The journey line through the sphere centres.
  const journey = (() => {
    const c = spheres.map((s) => sphereLayout[s.id]);
    let d = `M ${c[0].x} ${c[0].y}`;
    for (let i = 1; i < c.length; i++) {
      const my = (c[i - 1].y + c[i].y) / 2;
      d += ` C ${c[i - 1].x} ${my}, ${c[i].x} ${my}, ${c[i].x} ${c[i].y}`;
    }
    return d;
  })();

  // Drift: each sphere moves in a straight line inside a tiny box and bounces off its edges.
  // Sideways and up-down run as separate back-and-forth motions with different speeds, which is exactly a DVD bounce.
  const DRIFT_PX = 3.5; // half the box size, in screen pixels
  const drift = spheres.map((s, i) => ({
    dx: 7 + ((i * 2.3) % 5),
    dy: 9.5 + ((i * 3.1) % 6),
    delay: -((i * 4.7) % 9),
  }));

  // ---- camera ----
  // The map scrolls like a feed: up and down, with momentum, stopping at the top and bottom.
  // Sideways movement opens only when zoomed in so far that the map is wider than the screen.
  const TOP_PAD = 130; // room under the search bar
  const BOTTOM_PAD = 190; // room above the bottom cards
  const worldW = world.maxX - world.minX;
  const worldH = world.maxY - world.minY;
  // Farthest-out zoom = the start view (map fits the phone width). Pinching past it stretches a little and springs back.
  let minK = $derived((W - 24) / worldW);
  const MAX_K = 4;
  const clampK = (k) => Math.min(MAX_K, Math.max(minK, k));

  // Allowed range of cam.x / cam.y for a given zoom. When the map is smaller than the screen, it stays centred.
  function limits(k) {
    let xMin = W - 12 - world.maxX * k, xMax = 12 - world.minX * k;
    if (xMin > xMax) xMin = xMax = W / 2 - ((world.minX + world.maxX) / 2) * k;
    let yMin = H - BOTTOM_PAD - world.maxY * k, yMax = TOP_PAD - world.minY * k;
    if (yMin > yMax) yMin = yMax = (TOP_PAD + H - BOTTOM_PAD) / 2 - ((world.minY + world.maxY) / 2) * k;
    return { xMin, xMax, yMin, yMax };
  }
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  function clampCam(c) {
    const L = limits(c.k);
    return { k: c.k, x: clamp(c.x, L.xMin, L.xMax), y: clamp(c.y, L.yMin, L.yMax) };
  }
  // Past an edge the map follows the finger at a third of the speed, then springs back (rubber band).
  function rubber(v, a, b, d) {
    return v + (v + d < a || v + d > b ? d * 0.33 : d);
  }
  // Zoom so that screen point (px, py) stays under the finger.
  const zoomed = (c, px, py, k) => ({ k, x: px - (px - c.x) * (k / c.k), y: py - (py - c.y) * (k / c.k) });

  function zoomAt(px, py, f) {
    cam = clampCam(zoomed(cam, px, py, clampK(cam.k * f)));
  }

  // The scroll bar shows while the map moves, then fades.
  let barOn = $state(false);
  let barTimer;
  let lastMove = 0;
  const poke = () => {
    lastMove = performance.now();
    barOn = true;
    clearTimeout(barTimer);
    barTimer = setTimeout(() => (barOn = false), 900);
  };
  let bar = $derived.by(() => {
    const L = limits(cam.k);
    const view = H - TOP_PAD - BOTTOM_PAD;
    const content = worldH * cam.k;
    if (content <= view + 1) return null;
    const p = clamp((L.yMax - cam.y) / (L.yMax - L.yMin), 0, 1);
    const size = Math.max(36, (view / content) * view);
    return { top: TOP_PAD + p * (view - size), size };
  });

  let anim;
  function animateTo(to, dur, easing, done) {
    cancelAnimationFrame(anim);
    const from = { ...cam };
    const t0 = performance.now();
    dur = ms(dur);
    const step = (t) => {
      const p = dur ? Math.min(1, (t - t0) / dur) : 1;
      const e = easing(p);
      cam = { k: from.k + (to.k - from.k) * e, x: from.x + (to.x - from.x) * e, y: from.y + (to.y - from.y) * e };
      poke();
      if (p < 1) anim = requestAnimationFrame(step);
      else done?.();
    };
    anim = requestAnimationFrame(step);
  }
  const easeInOut = (p) => (p < 0.5 ? 4 * p * p * p : 1 - Math.pow(-2 * p + 2, 3) / 2);
  const easeOut = (p) => 1 - Math.pow(1 - p, 3);
  // Back inside the limits: zoom first (around the last pinch point), then the edges.
  let pinchAt = { x: 200, y: 400 };
  const springBack = () => animateTo(clampCam(zoomed(cam, pinchAt.x, pinchAt.y, clampK(cam.k))), 380, easeOut);

  function flyTo(wx, wy, k, dur = 650, at = 0.45) {
    k = clampK(k);
    animateTo(clampCam({ k, x: W / 2 - wx * k, y: H * at - wy * k }), dur, easeInOut);
  }

  // Momentum after a flick: speed decays like iOS scrolling; hitting an edge brakes hard, then springs back.
  function glide(vx, vy) {
    cancelAnimationFrame(anim);
    if (reduced) return springBack();
    let t0 = performance.now();
    const step = (t) => {
      const dt = Math.min(32, t - t0);
      t0 = t;
      const L = limits(cam.k);
      const out = cam.y < L.yMin || cam.y > L.yMax || cam.x < L.xMin || cam.x > L.xMax;
      const decay = Math.pow(out ? 0.97 : 0.998, dt);
      vx *= decay;
      vy *= decay;
      cam = { ...cam, x: cam.x + vx * dt, y: cam.y + vy * dt };
      poke();
      if (Math.hypot(vx, vy) > 0.02) anim = requestAnimationFrame(step);
      else springBack();
    };
    anim = requestAnimationFrame(step);
  }

  const flyToTopic = (id, open = true) => {
    const t = topicLayout[id];
    // The topic card covers the lower half, so the topic settles in the upper part of the screen.
    flyTo(t.x, t.y, Math.max(cam.k, Math.min(W, H) / (t.r * 7)), 650, open ? 0.26 : 0.45);
    if (open) ui.topic = id;
  };
  const flyToSphere = (id) => {
    const s = sphereLayout[id];
    flyTo(s.x, s.y, Math.min(W, H) / (s.R * 2.5));
  };

  // Opening a sphere: the map zooms into it, then its topic circles fly on to their places in the sub-map.
  let opening = false;
  function openSphere(id) {
    if (opening) return;
    opening = true;
    const s = sphereLayout[id];
    const k = Math.min(W - 32, H - 260) / (s.R * 2);
    const into = { k, x: W / 2 - s.x * k, y: H * 0.5 - s.y * k };
    ui.cam = { ...cam };
    animateTo(into, 420, easeInOut, () => {
      const rects = {};
      for (const t of sphereById[id].topics) {
        const L = topicLayout[t];
        rects[t] = { x: L.x * cam.k + cam.x, y: L.y * cam.k + cam.y, r: L.r * cam.k };
      }
      ui.morph = { sphere: id, rects };
      ui.zoomed = { ...cam };
      go('/s/' + id);
    });
  }

  // ---- pointers: one finger scrolls (with momentum), pinch zooms, tap opens ----
  const pts = new Map();
  let moved = 0;
  let last = null;
  let track = []; // recent finger positions, for the flick speed
  let stoppedGlide = false; // a tap that stops a moving map does not open anything
  function down(e) {
    // A new first finger means no other finger is down, so forget any finger whose "up" got lost.
    if (e.isPrimary) pts.clear();
    stoppedGlide = pts.size === 0 && performance.now() - lastMove < 60;
    cancelAnimationFrame(anim);
    try { svg.setPointerCapture(e.pointerId); } catch { /* pointer already gone */ }
    pts.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (pts.size === 1) moved = 0;
    last = null;
    track = [{ t: e.timeStamp, x: e.clientX, y: e.clientY }];
  }
  function move(e) {
    if (!pts.has(e.pointerId) || opening) return;
    const prev = pts.get(e.pointerId);
    pts.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (pts.size === 1) {
      const dx = e.clientX - prev.x, dy = e.clientY - prev.y;
      moved += Math.abs(dx) + Math.abs(dy);
      if (moved > 6) {
        const L = limits(cam.k);
        cam = { ...cam, x: L.xMin === L.xMax ? L.xMin : rubber(cam.x, L.xMin, L.xMax, dx), y: rubber(cam.y, L.yMin, L.yMax, dy) };
        track.push({ t: e.timeStamp, x: e.clientX, y: e.clientY });
        track = track.filter((p) => e.timeStamp - p.t < 100);
        poke();
      }
    } else if (pts.size === 2) {
      const [a, b] = [...pts.values()];
      const mid = { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 };
      const dist = Math.hypot(a.x - b.x, a.y - b.y);
      if (last && last.dist > 0) {
        // Past the farthest-out zoom the map resists (Clash of Clans style) and springs back on release.
        const raw = last.raw * (dist / last.dist);
        const k = raw >= minK ? Math.min(MAX_K, raw) : minK * Math.max(0.82, Math.pow(raw / minK, 0.3));
        cam = zoomed({ ...cam, x: cam.x + mid.x - last.mid.x, y: cam.y + mid.y - last.mid.y }, mid.x, mid.y, k);
        last = { mid, dist, raw: Math.max(raw, minK * 0.3) };
        pinchAt = mid;
        poke();
      } else {
        last = { mid, dist, raw: cam.k };
      }
      moved = 99;
    }
  }
  function up(e) {
    if (!pts.has(e.pointerId)) return;
    const wasTap = pts.size === 1 && moved <= 6 && !stoppedGlide;
    const wasScroll = pts.size === 1 && moved > 6 && !last;
    pts.delete(e.pointerId);
    if (pts.size === 1) {
      // One finger left after a pinch: carry on scrolling from here without a jump.
      const [p] = pts.values();
      track = [{ t: e.timeStamp, ...p }];
      last = null;
      return;
    }
    last = null;
    if (pts.size) return;
    if (opening) return;
    if (wasScroll) {
      const a = track[0], b = track[track.length - 1];
      const dt = b && a ? b.t - a.t : 0;
      const L = limits(cam.k);
      if (dt > 10 && e.timeStamp - b.t < 60) glide(L.xMin === L.xMax ? 0 : (b.x - a.x) / dt, (b.y - a.y) / dt);
      else springBack();
      return;
    }
    if (!wasTap) {
      springBack();
      return;
    }
    const el = document.elementFromPoint(e.clientX, e.clientY)?.closest('[data-topic],[data-sphere]');
    if (!el) {
      ui.topic = null;
    } else if (el.dataset.topic && detail > 0.5) {
      ui.topic = el.dataset.topic;
      progress.seen[el.dataset.topic] = Date.now();
    } else {
      openSphere(el.dataset.sphere ?? topics[el.dataset.topic].sphere);
    }
  }
  function cancel(e) {
    pts.delete(e.pointerId);
    last = null;
    if (!pts.size) springBack();
  }

  onMount(() => {
    const resize = () => {
      W = innerWidth;
      H = innerHeight;
      cam = clampCam({ ...cam, k: clampK(cam.k) });
    };
    resize();
    addEventListener('resize', resize);
    // Wheel scrolls the map like a page; Ctrl+wheel (and trackpad pinch, which sends Ctrl) zooms.
    const wheel = (e) => {
      e.preventDefault();
      cancelAnimationFrame(anim);
      const unit = e.deltaMode === 1 ? 40 : e.deltaMode === 2 ? H : 1;
      if (e.ctrlKey) zoomAt(e.clientX, e.clientY, Math.exp(-e.deltaY * unit * 0.01));
      else cam = clampCam({ ...cam, x: cam.x - e.deltaX * unit, y: cam.y - e.deltaY * unit });
      poke();
    };
    svg.addEventListener('wheel', wheel, { passive: false });
    if (ui.fly) {
      if (ui.fly.sphere) flyToSphere(ui.fly.sphere);
      else flyToTopic(ui.fly.topic);
      ui.fly = null;
      ui.zoomed = null;
    } else if (ui.zoomed) {
      // Back from a sphere: start zoomed into it and ease out to where the map was.
      const back = clampCam({ ...ui.cam, k: clampK(ui.cam.k) });
      cam = ui.zoomed;
      ui.zoomed = null;
      animateTo(back, 520, easeInOut);
    } else if (!ui.cam) {
      // First look: the map fits the phone's width, scrolled to the sphere with the next step (or the first one).
      const s = sphereLayout[spheres[next ? sphereById[topics[next].sphere].index : 0].id];
      const k = minK;
      cam = clampCam({ k, x: 0, y: H * 0.45 - s.y * k });
    }
    return () => {
      removeEventListener('resize', resize);
      svg.removeEventListener('wheel', wheel);
      cancelAnimationFrame(anim);
      if (!opening) ui.cam = { ...cam };
    };
  });

  // Prerequisite links show only for the selected topic.
  let links = $derived.by(() => {
    if (!selected || !topics[selected]) return [];
    const t = topicLayout[selected];
    return [
      ...topics[selected].req.map((r) => ({ a: topicLayout[r], b: t, kind: 'req' })),
      ...topicUnlocks[selected].map((u) => ({ a: t, b: topicLayout[u], kind: 'unlock' })),
    ];
  });
  const curve = (a, b) => {
    const mx = (a.x + b.x) / 2, my = (a.y + b.y) / 2;
    const dx = b.x - a.x, dy = b.y - a.y;
    return `M ${a.x} ${a.y} Q ${mx - dy * 0.2} ${my + dx * 0.2} ${b.x} ${b.y}`;
  };
  // Sphere titles stay fully on screen even when the sphere sits at the edge.
  const titleX = (wx, text) => {
    const half = [...text].length * 5.6 + 8;
    return (clamp(wx * cam.k + cam.x, half, W - half) - cam.x) / cam.k;
  };
  const fsFor = (text, r) => Math.min(r * 0.52, (r * 2.6) / Math.max(3, [...text].length));

  // ---- goal, then level ----
  // No "next step" until we know the student's level: first the goal, then a short check.
  let picking = $state(false);
  let showGoal = $derived(!progress.goalPicked || picking);
  let showLevel = $derived(progress.goalPicked && !levelChecked() && !progress.startDismissed && !picking);
  let goalName = $derived(GOALS.find((g) => g.id === progress.goal)?.name);
  function pickGoal(id) {
    const first = !progress.goalPicked;
    progress.goal = id;
    progress.goalPicked = true;
    save();
    picking = false;
    if (first && !levelChecked()) {
      ui.cam = { ...cam };
      go('/start');
    }
  }
</script>

<div class="map">
  <svg
    bind:this={svg}
    width={W}
    height={H}
    onpointerdown={down}
    onpointermove={move}
    onpointerup={up}
    onpointercancel={cancel}
    onlostpointercapture={(e) => pts.has(e.pointerId) && cancel(e)}
    role="application"
    aria-label="Математикийн газрын зураг"
  >
    <defs>
      {#each spheres as s}
        <radialGradient id="g-{s.id}" cx="50%" cy="45%" r="55%">
          <stop offset="0%" stop-color={sphereLayout[s.id].color} stop-opacity="0.28" />
          <stop offset="70%" stop-color={sphereLayout[s.id].color} stop-opacity="0.08" />
          <stop offset="100%" stop-color={sphereLayout[s.id].color} stop-opacity="0.02" />
        </radialGradient>
      {/each}
      {#each Object.values(topics) as t}
        <radialGradient id="t-{t.id}" cx="40%" cy="35%" r="70%">
          <stop offset="0%" stop-color={topicLayout[t.id].color} stop-opacity="0.55" />
          <stop offset="100%" stop-color={topicLayout[t.id].color} stop-opacity="0.08" />
        </radialGradient>
      {/each}
    </defs>

    <g transform="translate({cam.x} {cam.y}) scale({cam.k})" style:--a="{DRIFT_PX / cam.k}px">
      {#each stars as st}<circle cx={st.x} cy={st.y} r={st.s / Math.sqrt(cam.k)} class="star" opacity={st.o} />{/each}

      <path d={journey} class="journey" style:stroke-width={3 / Math.sqrt(cam.k)} />

      {#each spheres as s, i (s.id)}
        {@const L = sphereLayout[s.id]}
        {@const st = sphereState(s)}
        {@const label = `${s.index + 1}. ${s.title}`}
        <g class="dx" style:animation-duration="{drift[i].dx}s" style:animation-delay="{drift[i].delay}s">
          <g class="dy" style:animation-duration="{drift[i].dy}s" style:animation-delay="{drift[i].delay * 1.3}s">
            <g class="sphere {st}" data-sphere={s.id} style:--c={L.color}>
              <circle cx={L.x} cy={L.y} r={L.R} fill="url(#g-{s.id})" class="body" />
              <circle cx={L.x} cy={L.y} r={L.R} class="rim" style:stroke-width={2 / cam.k} />
              {#if st === 'next'}<circle cx={L.x} cy={L.y} r={L.R + 14 / cam.k} class="pulse" style:stroke-width={3 / cam.k} />{/if}
              <text x={L.x} y={L.y + L.R * 0.12} class="sformula" font-size={L.R * 0.34} opacity={1 - detail}>{s.formula}</text>
              {#if detail < 0.3}
                <text x={L.x} y={L.y + L.R * 0.45} class="scount" font-size={L.R * 0.1} opacity={1 - detail * 3}>
                  {s.topics.length} сэдэв
                </text>
              {/if}
            </g>
          </g>
        </g>
        <text x={titleX(L.x, label)} y={L.y - L.R - 22 / cam.k} class="stitle" class:next={st === 'next'} font-size={18 / cam.k}>{label}</text>
      {/each}

      {#each links as l}
        <path d={curve(l.a, l.b)} class="link {l.kind}" style:stroke-width={2.5 / cam.k} />
      {/each}

      <g class="topics" opacity={detail} style:pointer-events={detail > 0.5 ? 'auto' : 'none'}>
        {#each spheres as s, i (s.id)}
          <!-- Same drift as the sphere, so the topics ride along with it. -->
          <g class="dx" style:animation-duration="{drift[i].dx}s" style:animation-delay="{drift[i].delay}s">
            <g class="dy" style:animation-duration="{drift[i].dy}s" style:animation-delay="{drift[i].delay * 1.3}s">
              {#each s.topics as id (id)}
                {@const t = topics[id]}
                {@const L = topicLayout[id]}
                {@const st = topicState(id)}
                {@const lines = twoLines(t.name)}
                <g class="topic {st}" class:sel={selected === id} data-topic={id} style:--c={L.color}>
                  <circle cx={L.x} cy={L.y} r={L.r} fill="url(#t-{id})" class="tb" />
                  <circle cx={L.x} cy={L.y} r={L.r} class="tr" />
                  {#if st === 'next'}<circle cx={L.x} cy={L.y} r={L.r * 1.18} class="tpulse" />{/if}
                  <text x={L.x} y={L.y - L.r * 0.08} class="formula" font-size={fsFor(t.formula, L.r)}>{t.formula}</text>
                  {#each lines as line, j}
                    <text x={L.x} y={L.y + L.r * (0.38 + j * 0.2)} class="tname" font-size={L.r * 0.15}>{line}</text>
                  {/each}
                  {#if st === 'known' || st === 'faded'}
                    <text x={L.x + L.r * 0.7} y={L.y - L.r * 0.62} class="tick" font-size={L.r * 0.3}>✓</text>
                  {/if}
                </g>
              {/each}
            </g>
          </g>
        {/each}
      </g>
    </g>
  </svg>

  {#if bar}<div class="sbar" class:on={barOn} style:top="{bar.top}px" style:height="{bar.size}px" aria-hidden="true"></div>{/if}

  <!-- Screen-reader and keyboard route through the same content. -->
  <nav class="vh" aria-label="Бөмбөлгүүд">
    {#each spheres as s}<a href="#/s/{s.id}">{s.index + 1}. {s.title}</a>{/each}
  </nav>

  <header class="hud-top">
    <div class="toprow">
      <div class="brand">Математикийн аялал</div>
      {#if progress.goalPicked && !picking}
        <button class="goalchip" onclick={() => (picking = true)} transition:fly={{ y: -8, duration: ms(220), easing: ease }}>
          <span class="muted">Зорилго:</span> {goalName}
        </button>
      {/if}
    </div>
    <label class="search">
      <span class="vh">Хайх</span>
      <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="7" /><path d="m20 20-3.5-3.5" /></svg>
      <input type="search" bind:value={q} placeholder="Хүссэн зүйлээ асуу" autocomplete="off" enterkeyhint="search" />
    </label>
    {#if q.trim()}
      <div class="results" transition:fly={{ y: -8, duration: ms(200), easing: ease }}>
        {#if looksLikeMath(q)}<p class="preview">{@html formatMath(q)}</p>{/if}
        {#each results as r (r.kind + r.id)}
          <button
            class="res"
            onclick={() => {
              if (r.kind === 'topic') { q = ''; flyToTopic(r.id); } else { ui.cam = { ...cam }; go('/e/' + r.id); }
            }}
          >
            <span class="rf">{r.kind === 'topic' ? r.item.formula : r.item.symbol ?? '·'}</span>
            <span class="rt">
              <strong>{r.kind === 'topic' ? r.item.name : r.item.title}</strong>
              <span class="small muted">{r.kind === 'topic' ? 'Газрын зураг · ' + sphereById[r.item.sphere].title : 'Толь бичиг · ' + r.item.type}</span>
            </span>
          </button>
        {:else}
          <p class="small muted pad">Одоогоор олдсонгүй. Өөр үгээр асууж үзээрэй.</p>
        {/each}
      </div>
    {/if}
  </header>

  <div class="hud-bottom">
    {#if showGoal}
      <div class="goal" transition:fly={{ y: 40, duration: ms(320), easing: ease }}>
        <div class="ghead">
          <strong>Юу хүсэж байна?</strong>
          {#if picking}<button class="x" aria-label="Хаах" onclick={() => (picking = false)}>×</button>{/if}
        </div>
        {#each GOALS as g}
          <button class="gopt" class:on={progress.goalPicked && progress.goal === g.id} onclick={() => pickGoal(g.id)}>
            <strong>{g.name}</strong>
            <span class="small muted">{g.hint}</span>
          </button>
        {/each}
      </div>
    {:else if showLevel}
      <div class="start" transition:fly={{ y: 40, duration: ms(320), easing: ease }}>
        <div>
          <strong>Түвшнээ олъё</strong>
          <span class="small muted">Богино шалгалт · хаанаас эхлэхээ мэднэ</span>
        </div>
        <button class="btn sun" onclick={() => { ui.cam = { ...cam }; go('/start'); }}>Эхэлье!</button>
        <button class="x" aria-label="Хаах" onclick={() => { progress.startDismissed = true; save(); }}>×</button>
      </div>
    {/if}
  </div>
</div>

<style>
  .map { position: fixed; inset: 0; overflow: hidden; }
  svg { display: block; touch-action: none; cursor: grab; user-select: none; -webkit-user-select: none; }
  svg:active { cursor: grabbing; }
  .star { fill: #cfe8ff; }
  .journey { fill: none; stroke: var(--sky); stroke-opacity: 0.35; stroke-dasharray: 2 14; stroke-linecap: round; animation: flow 6s linear infinite; }
  @keyframes flow { to { stroke-dashoffset: -64; } }

  /* Drift: linear back-and-forth on each axis with different periods = a slow DVD-logo bounce. */
  .dx { animation: dx 9s linear infinite alternate; }
  .dy { animation: dy 11s linear infinite alternate; }
  @keyframes dx { from { transform: translateX(calc(-1 * var(--a))); } to { transform: translateX(var(--a)); } }
  @keyframes dy { from { transform: translateY(calc(-1 * var(--a))); } to { transform: translateY(var(--a)); } }

  .sphere { cursor: pointer; }
  .rim { fill: none; stroke: var(--c); stroke-opacity: 0.45; }
  .sphere.known .rim { stroke-opacity: 0.9; filter: drop-shadow(0 0 8px var(--c)); }
  .sphere.faded .rim { stroke: var(--dusk); }
  .sphere.later .body { opacity: 0.6; }
  .pulse { fill: none; stroke: var(--sun); animation: pulse 2.6s ease-in-out infinite; }
  @keyframes pulse { 50% { stroke-opacity: 0.2; } }
  .stitle { fill: var(--ink); font-weight: 800; text-anchor: middle; letter-spacing: 0.01em; paint-order: stroke; stroke: var(--bg); stroke-width: 6px; pointer-events: none; }
  .stitle.next { fill: var(--sun); }
  .sformula { fill: var(--c); text-anchor: middle; dominant-baseline: middle; font-family: var(--math); filter: drop-shadow(0 0 12px var(--c)); pointer-events: none; }
  .scount { fill: var(--muted); text-anchor: middle; font-weight: 600; pointer-events: none; }

  .topic { cursor: pointer; }
  .tr { fill: none; stroke: var(--c); stroke-width: 1.5; stroke-opacity: 0.55; transition: stroke-opacity 0.2s; }
  .formula { fill: #fff; text-anchor: middle; dominant-baseline: middle; font-family: var(--math); filter: drop-shadow(0 0 6px var(--c)); pointer-events: none; }
  .tname { fill: var(--ink); fill-opacity: 0.8; text-anchor: middle; font-weight: 600; pointer-events: none; }
  .tick { fill: var(--grass); font-weight: 800; pointer-events: none; }
  .topic.known .tr { stroke-opacity: 1; stroke-width: 3; filter: drop-shadow(0 0 6px var(--c)); }
  .topic.faded .tr { stroke: var(--dusk); stroke-width: 3; }
  .topic.later { opacity: 0.5; }
  .topic.sel .tr { stroke: #fff; stroke-width: 3; stroke-opacity: 1; }
  .tpulse { fill: none; stroke: var(--sun); stroke-width: 3; animation: pulse 2.2s ease-in-out infinite; }
  .link { fill: none; stroke-linecap: round; pointer-events: none; animation: draw 0.5s ease-out; }
  .link.req { stroke: var(--sky); stroke-opacity: 0.8; }
  .link.unlock { stroke: var(--sun); stroke-opacity: 0.6; stroke-dasharray: 6 8; }
  @keyframes draw { from { opacity: 0; } }

  .sbar { position: fixed; right: 4px; width: 4px; border-radius: 2px; background: var(--sky); opacity: 0; transition: opacity 0.4s; pointer-events: none; z-index: 4; }
  .sbar.on { opacity: 0.55; transition: opacity 0.1s; }

  .hud-top { position: fixed; top: 0; left: 0; right: 0; padding: 14px 16px 0; max-width: 560px; margin: 0 auto; z-index: 5; pointer-events: none; }
  .hud-top > * { pointer-events: auto; }
  .toprow { display: flex; align-items: center; justify-content: space-between; gap: 8px; min-height: 30px; margin-bottom: 8px; pointer-events: none; }
  .toprow > button { pointer-events: auto; }
  .brand { font-size: 0.8rem; font-weight: 800; letter-spacing: 0.3em; text-transform: uppercase; color: var(--sky); text-shadow: 0 0 12px rgba(34, 211, 238, 0.6); }
  .goalchip {
    min-height: 30px; padding: 0 12px; border-radius: 999px; font-size: 0.8rem; font-weight: 700; white-space: nowrap;
    background: rgba(10, 14, 24, 0.8); border: 1px solid rgba(255, 204, 102, 0.45); color: var(--sun); backdrop-filter: blur(8px);
  }
  .search {
    display: flex; align-items: center; gap: 10px; padding: 0 16px; min-height: 52px;
    background: rgba(10, 14, 24, 0.82); backdrop-filter: blur(12px);
    border: 1px solid rgba(34, 211, 238, 0.3); border-radius: 16px; box-shadow: 0 0 24px rgba(34, 211, 238, 0.12);
    transition: border-color 0.25s, box-shadow 0.25s;
  }
  .search:focus-within { border-color: var(--sky); box-shadow: 0 0 24px rgba(34, 211, 238, 0.3); }
  .search svg { width: 20px; height: 20px; fill: none; stroke: var(--sky); stroke-width: 2; stroke-linecap: round; flex: none; }
  .search input { flex: 1; min-width: 0; border: 0; outline: 0; background: none; font: inherit; font-size: 1rem; }
  .results { margin-top: 8px; max-height: 60vh; overflow-y: auto; background: rgba(10, 14, 24, 0.94); backdrop-filter: blur(12px); border: 1px solid var(--line); border-radius: 16px; padding: 6px; }
  .preview { margin: 4px 4px 8px; padding: 8px 12px; border-radius: 10px; background: var(--sky-soft); font-family: var(--math); font-size: 1.3rem; color: var(--sky-deep); }
  .res { display: flex; gap: 12px; align-items: center; width: 100%; padding: 10px; border: 0; background: none; text-align: left; border-radius: 12px; }
  .res:hover, .res:focus-visible { background: var(--sky-soft); outline: none; }
  .rf { min-width: 48px; height: 40px; padding: 0 6px; display: grid; place-items: center; border-radius: 10px; background: var(--sky-soft); color: var(--sky); font-family: var(--math); font-size: 0.95rem; white-space: nowrap; }
  .rt { display: grid; }
  .pad { padding: 10px; }

  .hud-bottom {
    position: fixed; left: 0; right: 0; bottom: 0; z-index: 5; display: grid; gap: 10px;
    padding: 0 84px calc(16px + env(safe-area-inset-bottom)) 16px; max-width: 640px; margin: 0 auto; pointer-events: none;
  }
  .hud-bottom > * { pointer-events: auto; grid-area: 1 / 1; }
  .start, .goal {
    border-radius: 18px; text-align: left;
    background: rgba(10, 14, 24, 0.9); backdrop-filter: blur(12px); border: 1px solid var(--line);
  }
  .start { position: relative; display: flex; align-items: center; gap: 10px; padding: 8px 34px 8px 12px; border-color: rgba(255, 204, 102, 0.45); box-shadow: 0 0 24px rgba(255, 204, 102, 0.12); }
  .start strong { font-size: 0.95rem; }
  .start > div { display: grid; flex: 1; }
  .start .btn { flex: none; min-height: 36px; padding: 0 14px; font-size: 0.85rem; }
  .x { position: absolute; top: 50%; transform: translateY(-50%); right: 4px; width: 28px; height: 28px; border: 0; background: none; color: var(--muted); font-size: 1.2rem; }
  .goal { display: grid; gap: 6px; padding: 12px; border-color: rgba(255, 204, 102, 0.45); box-shadow: 0 0 24px rgba(255, 204, 102, 0.15); }
  .ghead { position: relative; padding: 0 4px 2px; }
  .ghead .x { top: 50%; right: -4px; }
  .gopt { display: grid; gap: 1px; padding: 9px 12px; border-radius: 12px; border: 1px solid var(--line); background: rgba(255, 255, 255, 0.02); text-align: left; }
  .gopt strong { color: var(--sun); }
  .gopt:hover { border-color: rgba(255, 204, 102, 0.6); background: var(--sun-soft); }
  .gopt.on { border-color: var(--sun); background: var(--sun-soft); }

  @media (prefers-reduced-motion: reduce) {
    .dx, .dy, .journey, .pulse, .tpulse, .link { animation: none; }
  }
</style>
